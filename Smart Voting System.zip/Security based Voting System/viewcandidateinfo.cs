﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Security_based_Voting_System
{
    public partial class viewcandidateinfo : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\GOD\Desktop\sangeeth 2016\finger print\project1\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        public string id;

        public viewcandidateinfo()
        {
            InitializeComponent();
        }

        private void viewcandidateinfo_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
            }
            con.Close();




        }
    }
}
