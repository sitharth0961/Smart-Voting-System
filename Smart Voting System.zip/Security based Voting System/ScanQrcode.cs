﻿using System;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Luxand;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.IO;
using ZXing;
using ZXing.Client.Result;
using ZXing.Common;
using ZXing.Rendering;
using System.Xml;
using ZXing.Aztec;
using ZXingResult = ZXing.Result;



namespace Security_based_Voting_System
{
    public partial class ScanQrcode : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
       public String a;
        
       
        public ScanQrcode()
        {
            InitializeComponent();
        }

        String cameraName;
        bool needClose = false;
        private Timer webCamTimer;
        private readonly BarcodeReader barcodeReader;
        // WinAPI procedure to release HBITMAP handles returned by FSDKCam.GrabFrame
        [DllImport("gdi32.dll")]
        static extern bool DeleteObject(IntPtr hObject);

        private void button1_Click(object sender, EventArgs e)
        {
            this.button1.Enabled = false;
            int cameraHandle = 0;

            int r = FSDKCam.OpenVideoCamera(ref cameraName, ref cameraHandle);
            if (r != FSDK.FSDKE_OK)
            {
                MessageBox.Show("Error opening the first camera", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            int tracker = 0;
            FSDK.CreateTracker(ref tracker);

            int err = 0; // set realtime face detection parameters
            FSDK.SetTrackerMultipleParameters(tracker, "RecognizeFaces=false; DetectAge=true; DetectGender=true; HandleArbitraryRotations=false; DetermineFaceRotationAngle=false; InternalResizeWidth=100; FaceDetectionThreshold=7;", ref err);


            webCamTimer = new Timer();
            webCamTimer.Tick += webCamTimer_Tick;
            webCamTimer.Interval = 200;
            webCamTimer.Start();


            while (!needClose)
            {
                Int32 imageHandle = 0;
                if (FSDK.FSDKE_OK != FSDKCam.GrabFrame(cameraHandle, ref imageHandle)) // grab the current frame from the camera
                {
                    Application.DoEvents();
                    continue;
                }
                FSDK.CImage image = new FSDK.CImage(imageHandle);

                long[] IDs;
                long faceCount = 0;
                FSDK.FeedFrame(tracker, 0, image.ImageHandle, ref faceCount, out IDs, sizeof(long) * 256); // maximum 256 faces detected
                Array.Resize(ref IDs, (int)faceCount);

                Image frameImage = image.ToCLRImage();
                Graphics gr = Graphics.FromImage(frameImage);




                // display current frame
                pictureBox1.Image = frameImage;

                GC.Collect(); // collect the garbage

                // make UI controls accessible
                Application.DoEvents();
            }
            FSDK.FreeTracker(tracker);

            FSDKCam.CloseVideoCamera(cameraHandle);
            FSDKCam.FinalizeCapturing();
        }
       

        private void ScanQrcode_Load(object sender, EventArgs e)
        {
            
           // con.Open();
           // cmd = new SqlCommand("select *from regtb where Name='" + SessionName + "'", con);
            //SqlDataReader dr=new SqlDataReader();
            //if(dr.Read())
            //{
               // label2.Text = dr.["voter"].ToString();
           // }

            //con.Open();
            //cmd = new SqlCommand("SELECT * FROM regtb WHERE Name = @Name", con);
            //cmd.Parameters.AddWithValue("@Name", SessionName); // Use parameterized query to prevent SQL injection
            //SqlDataReader dr = cmd.ExecuteReader();

            //if (dr.Read())
            //{
            //    label2.Text = dr["voter"].ToString(); // Corrected syntax
            //    a = SessionName.ToString();
            //}
            //else
            //{
            //    label2.Text = "No record found"; // Handle case when no record is found
            //}

            //dr.Close();
            //con.Close();

         
            
            
            
            
            
            if (FSDK.FSDKE_OK != FSDK.ActivateLibrary("gyYgVWQTSzjiuGB/hH8dKgg0QrrIuhoHdfUCzD9rY+vru3WRZsaezTX6YWj9osdI/cmxY1NSdLkyWuugMPCxUG7/xNLegHLeaUpzVyKpDkaWL8tJIUsIL7xv9bhmgifPbAyTDuxF3VGxXmHkv/L/MStf9kdXV/A1vVvT93QC4vQ="))
            {
                MessageBox.Show("Please run the License Key Wizard (Start - Luxand - FaceSDK - License Key Wizard)", "Error activating FaceSDK", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            FSDK.InitializeLibrary();
            FSDKCam.InitializeCapturing();

            string[] cameraList;
            int count;
            FSDKCam.GetCameraList(out cameraList, out count);

            if (0 == count)
            {
                MessageBox.Show("Please attach a camera", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            cameraName = cameraList[0]; // choose the first camera

            FSDKCam.VideoFormatInfo[] formatList;
            FSDKCam.GetVideoFormatList(ref cameraName, out formatList, out count);

        }
        void webCamTimer_Tick(object sender, EventArgs e)
        {
            string decoded = "";
            BarcodeReader Reader = new BarcodeReader();

            Bitmap bmp = new Bitmap(pictureBox1.Image);

            //Result result = Reader.Decode((Bitmap)bmp);
            ZXingResult result = Reader.Decode(bmp);


            try
            {
                if (result == null) { return; }
                decoded = result.ToString().Trim();
                Console.WriteLine(decoded);
            }
            catch (Exception ex)
            {

            }
            if (decoded != "")
            {

                //if (decoded.ToString() == label2.Text)
                //{

                con.Open();
                cmd = new SqlCommand("SELECT * FROM regtb WHERE Name = @voter", con);
                cmd.Parameters.AddWithValue("@voter", decoded); // Use parameterized query to prevent SQL injection
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                   // label2.Text = dr["voter"].ToString(); // Corrected syntax
                    //a = SessionName.ToString();

                    SessionName = dr["Name"].ToString();
                    Console.WriteLine(SessionName);
                    
                }
                else
                {
                    label2.Text = "No record found"; // Handle case when no record is found
                }

                dr.Close();
                con.Close();
                    UserInfo aa = new UserInfo();
                    aa.un = decoded;
                    aa.Show();
                    this.Close();



               // }
               
            }
            else
            {
                MessageBox.Show("INVALID QRCODE");
            }
        }

        public string SessionName { get; set; }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            needClose = true;
            Application.Exit();
        }
    }
  }


