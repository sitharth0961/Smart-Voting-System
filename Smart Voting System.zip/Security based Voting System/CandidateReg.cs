﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;
using System.Data;
using System.Data.SqlClient;


namespace Security_based_Voting_System
{
    public partial class CandidateReg : Form
    {
        MemoryStream ms;
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        byte[] photo_aray;

        
        public CandidateReg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        void conv_photo()
        {
            //converting photo to binary data
            if (pictureBox1.Image != null)
            {
                ms = new MemoryStream();
                pictureBox1.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_aray = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_aray, 0, photo_aray.Length);
                cmd.Parameters.AddWithValue("@image", photo_aray);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int i = 1001;
            cmd = new SqlCommand("select * from cantb", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
            }
            con.Close();
            comboBox1.Text = "CANID" + i;


            cmd = new SqlCommand("insert into cantb values(@Canid,@Canname,@Code,@image)", con);
            cmd.Parameters.AddWithValue("@Canid", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Canname", textBox2.Text);
            cmd.Parameters.AddWithValue("@Code", textBox3.Text);
            conv_photo();
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Candidate Info Saved!");


        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand(" delete from cantb where Canid='" + comboBox1.Text + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Candidate Info Deleted!");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select * from cantb where Canid='" + comboBox1.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                //textBox2.Text = dr["Canid"].ToString();
                textBox2.Text = dr["Canname"].ToString();
                textBox3.Text = dr["Code"].ToString();
                photo_aray = (byte[])dr["image"];
                MemoryStream ms = new MemoryStream(photo_aray);
                pictureBox1.Image = Image.FromStream(ms);
            }
            con.Close();

        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select * from cantb ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["Canid"].ToString());
            }
            con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand(" update  cantb  set CanName='" + textBox2.Text + "',Code='" + textBox3.Text + "'  where Canid='" + comboBox1.Text + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Candidate Info Update!");

        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.ShowDialog();
            textBox4.Text = op.FileName;
            pictureBox1.Image = new Bitmap(op.FileName);
        }
    }
}
