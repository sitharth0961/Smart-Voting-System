﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;



namespace Security_based_Voting_System
{
    public partial class Voteform : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        string vote;

        public string gende,uname,voter;

        string mob;


        public Voteform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


          
        }

        private void Voteform_Load(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select * from cantb", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();

            con.Open();
            cmd = new SqlCommand("select * from regtb where voter='" + voter + "'  ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                mob = dr["Mobileno"].ToString();
                uname = dr["Name"].ToString();
            }
            else
            {
                MessageBox.Show("Username or Password incorrect!");
            }
            con.Close();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                string id = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                //MessageBox.Show(id);

                UsercanInfo u = new UsercanInfo();
                u.id = id;
                u.ShowDialog();

             
            }
            else if (e.ColumnIndex == 2)
            {
            }
            else if (e.ColumnIndex == 3)
            {
            }
            else if (e.ColumnIndex == 4)
            {
            }

            else 
            {

                string vote = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                //MessageBox.Show(vote);


                // Check if the voter has already voted
                cmd = new SqlCommand("SELECT COUNT(*) FROM votetb WHERE voter = @voter", con);
                cmd.Parameters.AddWithValue("@voter", voter);

                con.Open();
                int voteCount = (int)cmd.ExecuteScalar(); // Get the count of rows for this voter
                con.Close();

                if (voteCount > 0)
                {
                    // Voter has already voted
                    MessageBox.Show("You have already voted!");
                }
                else
                {
                    // Insert the vote
                    cmd = new SqlCommand("INSERT INTO votetb (voter, Party, Vote, Gender) VALUES (@voter, @Party, @Vote, @Gender)", con);
                    cmd.Parameters.AddWithValue("@voter", voter);
                    cmd.Parameters.AddWithValue("@Party", vote);
                    cmd.Parameters.AddWithValue("@Vote", "1");
                    cmd.Parameters.AddWithValue("@Gender", gende);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Vote Completed!");


                    string dd = uname + "Vote Time: " + System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString();


                    sendmessage(mob, dd);


                    // Close the current form
                    UserInfo u = new UserInfo();
                    u.Close();

                    
                }

               // cmd = new SqlCommand("insert into votetb values(@voter,@Party,@Vote,@Gender,)", con);
                //cmd.Parameters.AddWithValue("@voter", voter);
               // cmd.Parameters.AddWithValue("@Party", vote);
                //cmd.Parameters.AddWithValue("@Vote", "1");
                //cmd.Parameters.AddWithValue("@Gender", gende);
               
                //con.Open();
                //cmd.ExecuteNonQuery();
                //con.Close();
               // MessageBox.Show("Vote Completed!");
               // //Voteresult v = new Voteresult();
               // //v.Show();
               // UserInfo u = new UserInfo();
               // u.Close();

                VerificationForm v = new VerificationForm();
                v.Close();
                ss s = new ss();
                s.Close();

                this.Close();


            }
           

        }

        public void sendmessage(string targetno, string message)
        {
            String query = "http://sms.creativepoint.in/api/push.json?apikey=6555c521622c1&route=transsms&sender=FSSMSS&mobileno=" + targetno + "&text=Dear customer your msg is " + message + "  Sent By FSMSG FSSMSS";
            WebClient client = new WebClient();
            Stream sin = client.OpenRead(query);
            // MessageBox.Show("Message Send!");
            //Response.Write("<script> alert('Message Send') </script>");
        }
    }
}
