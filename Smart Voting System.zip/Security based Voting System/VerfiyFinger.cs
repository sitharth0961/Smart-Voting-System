﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Drawing.Imaging;
using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode;
using System.Net.Mail;
using System.Net;




namespace Security_based_Voting_System
{

    delegate void Function();

    public partial class VerfiyFinger : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        string gender;

        public string us;

        public VerfiyFinger()
        {
            InitializeComponent();
        }

        private void VerfiyFinger_Load(object sender, EventArgs e)
        {

            if (us == "user")
            {
                EnrollmentForm Enroller = new EnrollmentForm();
                Enroller.OnTemplate += this.OnTemplate;
                Enroller.fin = "user";
                Enroller.ShowDialog();
            }
            else
            {
                
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = Path.GetDirectoryName(Application.ExecutablePath.ToString()) + "\\QRcode\\";
            Random rrr = new Random();
            int newpass = rrr.Next(1111, 9999);

            string yourcode = textBox8.Text;
            QRCodeEncoder enc = new QRCodeEncoder();
            Bitmap qrcode = enc.Encode(yourcode);

            // Add a border to the QR code
            int borderWidth = 20; // Size of the border in pixels
            int newWidth = qrcode.Width + (2 * borderWidth);
            int newHeight = qrcode.Height + (2 * borderWidth);
            Bitmap qrcodeWithBorder = new Bitmap(newWidth, newHeight);

            // Draw the QR code with the border
            using (Graphics g = Graphics.FromImage(qrcodeWithBorder))
            {
                // Fill the border area with a color (e.g., white)
                g.Clear(Color.White);

                // Draw the original QR code in the center of the new image
                g.DrawImage(qrcode, borderWidth, borderWidth, qrcode.Width, qrcode.Height);
            }

            pictureBox1.Image = qrcodeWithBorder as Image;

            Random r = new Random();
            int ii = r.Next(11111, 99999);

            // Save the QR code with border
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path); // Ensure the directory exists
            }
            pictureBox1.Image.Save(path + ii + ".bmp", System.Drawing.Imaging.ImageFormat.Bmp);
            label11.Text = ii + ".bmp";



            string to = textBox5.Text;
            string from = "projectmailm@gmail.com";
            // string subject = "Key";
            // string body = TextBox1.Text;
            string password = "qmgnxeclbkqvmusr";
            using (MailMessage mm = new MailMessage(from, to))
            {
                mm.Subject = "Login Qrcode";
                mm.Body = label11.Text;

                Image image = pictureBox1.Image;
                System.IO.MemoryStream stream = new System.IO.MemoryStream();
                image.Save(stream, ImageFormat.Jpeg);
                stream.Position = 0;

                mm.Attachments.Add(new Attachment(stream, label11.Text));

                mm.IsBodyHtml = false;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential(from, password);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                smtp.Send(mm);


                MessageBox.Show("Mail Send!");

                //SaveFileDialog save = new SaveFileDialog();
                //save.Filter = "Fingerprint Template File (*.fpt)|*.fpt";
                //if (save.ShowDialog() == DialogResult.OK)
                //{
                //    using (FileStream fs = File.Open(save.FileName, FileMode.Create, FileAccess.Write))
                //    {
                //        Template.Serialize(fs);
                //    }
                //}


                if (Convert.ToInt32(textBox3.Text) <= 17 || textBox5.Text == "")
                {


                    MessageBox.Show("Age Limit Exit");
                }
                else
                {



                    if (radioButton1.Checked == true)
                    {
                        gender = radioButton1.Text;
                    }
                    else
                    {
                        gender = radioButton2.Text;
                    }


                    MemoryStream fingerprintData = new MemoryStream();
                    Template.Serialize(fingerprintData);
                    fingerprintData.Position = 0;
                    BinaryReader br = new BinaryReader(fingerprintData);
                    Byte[] bytes = br.ReadBytes((Int32)fingerprintData.Length);

                    //const string sPath = "D:\\newdataset.fpt";

                    cmd = new SqlCommand("insert into regtb values(@Name,@FatherName,@Gender,@Dob,@Age,@MobileNo,@Email,@Address,@voter,@finger,@Password)", con);
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@FatherName", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@Dob", dateTimePicker1.Text);
                    cmd.Parameters.AddWithValue("@Age", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Mobileno", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Email", textBox5.Text);
                    cmd.Parameters.AddWithValue("@Address", textBox6.Text);
                   
                    cmd.Parameters.AddWithValue("@voter", textBox8.Text);
                    cmd.Parameters.AddWithValue("@finger", bytes);
                    cmd.Parameters.AddWithValue("@Password", textBox7.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();





                    MessageBox.Show("Record Save!");
                }


            }
        }

        private void OnTemplate(DPFP.Template template)
        {
            this.Invoke(new Function(delegate()
            {
                Template = template;
                //VerifyButton.Enabled = SaveButton.Enabled = (Template != null);
                if (Template != null)
                    MessageBox.Show("The fingerprint template is ready for fingerprint verification.", "Fingerprint Enrollment");
                else
                    MessageBox.Show("The fingerprint template is not valid. Repeat fingerprint enrollment.", "Fingerprint Enrollment");
            }));
        }

        private DPFP.Template Template;

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            int year1, year2;
            year1 = System.DateTime.Now.Year;
            year2 = dateTimePicker1.Value.Year;
            int aa = year1 - year2;

            textBox3.Text = aa.ToString();


        }

        private void textBox6_MouseClick(object sender, MouseEventArgs e)
       {
           string pattern = null;
           //pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
           pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

           if (Regex.IsMatch(textBox5.Text, pattern))
           {
                MessageBox.Show("Valid Email address ");
           }
            else
            {
               textBox5.Text = "";
                MessageBox.Show("Not a valid Email address ");
            }
        }



        public object bytes { get; set; }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
