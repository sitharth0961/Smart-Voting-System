using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;



namespace Security_based_Voting_System
{
	/* NOTE: This form is inherited from the CaptureForm,
		so the VisualStudio Form Designer may not load it properly
		(at least until you build the project).
		If you want to make changes in the form layout - do it in the base CaptureForm.
		All changes in the CaptureForm will be reflected in all derived forms 
		(i.e. in the EnrollmentForm and in the VerificationForm)
	*/
	public class VerificationForm : CaptureForm
	{

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
          //string  photo_aray;
          byte[] photodat;
          //string uname, password;


		public void Verify(DPFP.Template template)
		{
			Template = template;
			ShowDialog();
		}

		protected override void Init()
		{
			base.Init();
			base.Text = "Fingerprint Verification";
			Verificator = new DPFP.Verification.Verification();		// Create a fingerprint template verificator
			UpdateStatus(0);
		}
        public string uname, gender, password,voter;
 
		protected override void Process(DPFP.Sample Sample)
		{


			base.Process(Sample);

			// Process the sample and create a feature set for the enrollment purpose.
			DPFP.FeatureSet features = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification);

			// Check quality of the sample and start verification if it's good
			// TODO: move to a separate task
            DPFP.Verification.Verification ver = new DPFP.Verification.Verification();
            DPFP.Verification.Verification.Result res = new DPFP.Verification.Verification.Result();

            con.Open();
            cmd = new SqlCommand("select * from regtb where Name='" + fin + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if  (dr.Read())
            {

                 photodat = (byte[])dr["finger"];

                 uname = dr["Name"].ToString();
                 password = dr["Password"].ToString();
                 gender = dr["gender"].ToString();
                 voter = dr["voter"].ToString();


            }

            con.Close();

            if (features != null)
            {
                // Compare the feature set with our template
                DPFP.Template template = new DPFP.Template();
                template.DeSerialize(photodat);
                DPFP.Verification.Verification.Result result = new DPFP.Verification.Verification.Result();
                Verificator.Verify(features, template, ref result);
                UpdateStatus(result.FARAchieved);
                if (result.Verified)
                {
                    MakeReport("The fingerprint was VERIFIED.");
                    //Voteing v = new Voteing();
                    //v.Show();
                    //this.Hide();

                    //UserInfo uf = new UserInfo();
                    //uf.un = uname;
                   /// uf.up = password;
                    //uf.Show();
                    //this.Invalidate();
                    //this.Hide();

                    Voteform v = new Voteform();
                    v.gende = gender;
                    v.voter = voter;
                    v.Show();


                }
                else
                {

                    MakeReport("The fingerprint was NOT VERIFIED.");
                }
            }



           

		}
 private static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }


       
		private void UpdateStatus(int FAR)
		{
			// Show "False accept rate" value
			SetStatus(String.Format("False Accept Rate (FAR) = {0}", FAR));
		}

		private DPFP.Template Template;
		private DPFP.Verification.Verification Verificator;

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // VerificationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackgroundImage = global::Security_based_Voting_System.Properties.Resources.images;
            this.ClientSize = new System.Drawing.Size(581, 354);
            this.Name = "VerificationForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {

        }

	}
}