﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_based_Voting_System
{
    public partial class VoterInfo : Form
    {
        public VoterInfo()
        {
            InitializeComponent();
        }

        private void VoterInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'fingerDataSet.regtb' table. You can move, or remove it, as needed.
            this.regtbTableAdapter.Fill(this.fingerDataSet.regtb);

            this.reportViewer1.RefreshReport();
        }
    }
}
