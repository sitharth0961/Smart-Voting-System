﻿namespace Security_based_Voting_System
{
    partial class Voteform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CanInfo = new System.Windows.Forms.DataGridViewButtonColumn();
            this.CanName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VoteSymbol = new System.Windows.Forms.DataGridViewImageColumn();
            this.VoteHere = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CanInfo,
            this.CanName,
            this.Code,
            this.VoteSymbol,
            this.VoteHere});
            this.dataGridView1.Location = new System.Drawing.Point(56, 101);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(617, 465);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // CanInfo
            // 
            this.CanInfo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CanInfo.DataPropertyName = "Canid";
            this.CanInfo.HeaderText = "CandInfo";
            this.CanInfo.Name = "CanInfo";
            this.CanInfo.Text = "CandInfo";
            // 
            // CanName
            // 
            this.CanName.DataPropertyName = "CanName";
            this.CanName.HeaderText = "CanName";
            this.CanName.Name = "CanName";
            // 
            // Code
            // 
            this.Code.DataPropertyName = "Code";
            this.Code.HeaderText = "Code";
            this.Code.Name = "Code";
            // 
            // VoteSymbol
            // 
            this.VoteSymbol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.VoteSymbol.DataPropertyName = "image";
            this.VoteSymbol.HeaderText = "VoteSymbol";
            this.VoteSymbol.MinimumWidth = 50;
            this.VoteSymbol.Name = "VoteSymbol";
            // 
            // VoteHere
            // 
            this.VoteHere.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.VoteHere.HeaderText = "Vote ";
            this.VoteHere.Name = "VoteHere";
            this.VoteHere.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.VoteHere.Text = "Vote Here..";
            this.VoteHere.ToolTipText = "Vote";
            this.VoteHere.UseColumnTextForButtonValue = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(296, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vote Here...";
            // 
            // Voteform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Security_based_Voting_System.Properties.Resources.images;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(778, 615);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Voteform";
            this.Text = "Voteform";
            this.Load += new System.EventHandler(this.Voteform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewButtonColumn CanInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Code;
        private System.Windows.Forms.DataGridViewImageColumn VoteSymbol;
        private System.Windows.Forms.DataGridViewButtonColumn VoteHere;

    }
}