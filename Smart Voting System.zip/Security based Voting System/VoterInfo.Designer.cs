﻿namespace Security_based_Voting_System
{
    partial class VoterInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.fingerDataSet = new Security_based_Voting_System.fingerDataSet();
            this.regtbBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.regtbTableAdapter = new Security_based_Voting_System.fingerDataSetTableAdapters.regtbTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.fingerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regtbBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.regtbBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Security_based_Voting_System.Candidate.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(690, 393);
            this.reportViewer1.TabIndex = 0;
            // 
            // fingerDataSet
            // 
            this.fingerDataSet.DataSetName = "fingerDataSet";
            this.fingerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // regtbBindingSource
            // 
            this.regtbBindingSource.DataMember = "regtb";
            this.regtbBindingSource.DataSource = this.fingerDataSet;
            // 
            // regtbTableAdapter
            // 
            this.regtbTableAdapter.ClearBeforeFill = true;
            // 
            // VoterInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 393);
            this.Controls.Add(this.reportViewer1);
            this.Name = "VoterInfo";
            this.Text = "VoterInfo";
            this.Load += new System.EventHandler(this.VoterInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fingerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regtbBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource regtbBindingSource;
        private fingerDataSet fingerDataSet;
        private fingerDataSetTableAdapters.regtbTableAdapter regtbTableAdapter;
    }
}