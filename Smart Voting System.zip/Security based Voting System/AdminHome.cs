﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_based_Voting_System
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void userInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //UserDetails ud = new UserDetails();
            //ud.Show();

            VoterInfo v = new VoterInfo();
            v.Show();

        }

        private void resultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Result r = new Result();
            //r.Show();

            Voteresult v = new Voteresult();
            v.Show();


        }

        private void candiateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CandidateReg r = new CandidateReg();
            r.Show();

        }

        private void newUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerfiyFinger f = new VerfiyFinger();
            f.us = "user";
            f.Show();
        }

        private void OnTemplate(DPFP.Template template)
        {
            this.Invoke(new Function(delegate()
            {
                Template = template;
                //VerifyButton.Enabled = SaveButton.Enabled = (Template != null);
                if (Template != null)
                    MessageBox.Show("The fingerprint template is ready for fingerprint verification.", "Fingerprint Enrollment");
                else
                    MessageBox.Show("The fingerprint template is not valid. Repeat fingerprint enrollment.", "Fingerprint Enrollment");
            }));
        }

        private DPFP.Template Template;
    }
}
