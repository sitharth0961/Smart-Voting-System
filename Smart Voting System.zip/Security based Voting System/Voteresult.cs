﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;



namespace Security_based_Voting_System
{
    public partial class Voteresult : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;

        public Voteresult()
        {
            InitializeComponent();
        }

        private void Voteresult_Load(object sender, EventArgs e)
        {
            BindChart();
            votcount();
            
        }

        private void BindChart()
        {
           

            string conString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True";
            SqlConnection conn = new SqlConnection(conString);
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select Party,  count(Vote)as Vote from votetb  group by Party", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds, "votetb");
                chart1.DataSource = ds.Tables["votetb"];
                chart1.Series["Series1"].XValueMember = "Party";
                chart1.Series["Series1"].YValueMembers = "Vote";


                // Set the chart title
                this.chart1.Titles.Add("Vote Result");
                //// Set chart type like Bar chart, Pie chart 
                chart1.Series["Series1"].ChartType = SeriesChartType.Pie;
                // To show chart value           
                chart1.Series["Series1"].IsValueShownAsLabel = true;
                //chart1.Series["Series2"].IsValueShownAsLabel = true;
                //label1.Text = n;
            }
            catch (Exception ex)
            {
                //Exception Message
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }




        }

        private void votcount()
        {


            con.Open();
            cmd = new SqlCommand("select count(*) as count from regtb ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                label9.Text = dr["count"].ToString();

            }
            con.Close();



            con.Open();
            cmd = new SqlCommand("select sum(Vote) as vote from votetb where Gender='Male'", con);
            SqlDataReader dr1 = cmd.ExecuteReader();
            if (dr1.Read())
            {

                label7.Text = dr1["Vote"].ToString();

            }
            con.Close();


            con.Open();
            cmd = new SqlCommand("select sum(Vote) as vote from votetb where Gender='Female'", con);
            SqlDataReader dr2 = cmd.ExecuteReader();
            if (dr2.Read())
            {

                label8.Text = dr2["Vote"].ToString();

            }
            con.Close();




            con.Open();
            cmd = new SqlCommand("select count(*) as count from votetb", con);
            SqlDataReader dr3 = cmd.ExecuteReader();
            if (dr3.Read())
            {

                label5.Text = dr3["count"].ToString();

            }
            con.Close();




            con.Open();
            cmd = new SqlCommand("SELECT TOP (1) Party, SUM(Vote) AS vote1 FROM votetb GROUP BY Party ORDER BY vote1 DESC", con);
            SqlDataReader dr4 = cmd.ExecuteReader();
            if (dr4.Read())
            {

                label11.Text = dr4["party"].ToString();

            }

            con.Close();



        }



        
    }
}
