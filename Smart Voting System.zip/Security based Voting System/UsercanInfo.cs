﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.IO;



namespace Security_based_Voting_System
{
    public partial class UsercanInfo : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        public string id;
        byte[] photo_aray;
        public UsercanInfo()
        {
            InitializeComponent();
        }

        private void UsercanInfo_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select * from cantb where Canid='" + id + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                label7.Text = dr["Canid"].ToString();
                label6.Text = dr["Canname"].ToString();
                label5.Text = dr["Code"].ToString();
                photo_aray = (byte[])dr["image"];
                MemoryStream ms = new MemoryStream(photo_aray);
                pictureBox1.Image = Image.FromStream(ms);
            }
            con.Close();

        }
    }
}
