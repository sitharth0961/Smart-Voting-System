﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Security_based_Voting_System
{
    public partial class UserInfo : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        public string un;
        string unnn, passw;

        public UserInfo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Voteform v = new Voteform();
            //v.gende = label15.Text;
            //v.Show();

            con.Open();
            cmd = new SqlCommand("select * from regtb  where voter='" + un + "' ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                unnn = dr["name"].ToString();
                passw = dr["password"].ToString();
                

            }
            con.Close();

            VerificationForm Verifier = new VerificationForm();
            Verifier.fin = unnn;
            Verifier.uname = passw;
            Verifier.password = passw;
            Verifier.Verify(Template);





            //Voteing v = new Voteing();
            //v.Show();

        }

        private void UserInfo_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select Name,FatherName,Gender,Dob,Age,Mobileno,Email,Address from regtb  where voter='" + un + "' ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                label17.Text = dr["Name"].ToString();
                label16.Text = dr["FatherName"].ToString();
                label15.Text = dr["Gender"].ToString();
                label14.Text = dr["Dob"].ToString();
                label13.Text = dr["Age"].ToString();
                label12.Text = dr["Mobileno"].ToString();
                label11.Text = dr["Email"].ToString();
                label10.Text = dr["Address"].ToString();

            }
            con.Close();
        }


        private void OnTemplate(DPFP.Template template)
        {
            this.Invoke(new Function(delegate()
            {
                Template = template;
                //VerifyButton.Enabled = SaveButton.Enabled = (Template != null);
                if (Template != null)
                    MessageBox.Show("The fingerprint template is ready for fingerprint verification.", "Fingerprint Enrollment");
                else
                    MessageBox.Show("The fingerprint template is not valid. Repeat fingerprint enrollment.", "Fingerprint Enrollment");
            }));
        }

        private DPFP.Template Template;
    }
}