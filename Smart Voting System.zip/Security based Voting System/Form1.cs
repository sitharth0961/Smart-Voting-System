﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Security_based_Voting_System
{
    //delegate void Function();

    public partial class ss : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=H:\RAGHUL (DOT NET)\WINDOWS APP\Security based Voting System\Security based Voting System\finger.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;

        public ss()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Admin")
            {

                if (textBox1.Text == "admin" & textBox2.Text == "admin")
                {
                    AdminHome a = new AdminHome();
                    a.Show();

                }
                else
                {
                    MessageBox.Show("Please give correct Password");
                }
            }
            else
            {



                con.Open();
                cmd = new SqlCommand("select * from regtb where Name='" + textBox1.Text + "' and Password='" + textBox2.Text + "' ", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    
                    ScanQrcode ss = new ScanQrcode();
                    ss.SessionName = textBox1.Text;
                    ss.Show();

                    //VerificationForm Verifier = new VerificationForm();
                   // Verifier.fin = textBox1.Text;
                    //Verifier.uname = textBox1.Text;
                    //Verifier.password = textBox2.Text;
                   // Verifier.Verify(Template);
                }
                else
                {
                    MessageBox.Show("Username or Password incorrect!");
                }
                con.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
          //  //EnrollmentForm Enroller = new EnrollmentForm();
           // //Enroller.OnTemplate += this.OnTemplate;
           // //Enroller.fin = "user";
           // //Enroller.ShowDialog();

            VerfiyFinger f = new VerfiyFinger();
            f.us = "user";
           f.Show();



        }



        private void OnTemplate(DPFP.Template template)
        {
            this.Invoke(new Function(delegate()
            {
                Template = template;
                //VerifyButton.Enabled = SaveButton.Enabled = (Template != null);
                if (Template != null)
                    MessageBox.Show("The fingerprint template is ready for fingerprint verification.", "Fingerprint Enrollment");
                else
                    MessageBox.Show("The fingerprint template is not valid. Repeat fingerprint enrollment.", "Fingerprint Enrollment");
            }));
        }

        private DPFP.Template Template;

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ScanQrcode sr = new ScanQrcode();
            sr.Show();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Admin")
            {
            }
            else
            {
                ScanQrcode ss = new ScanQrcode();
                ss.Show();

            }
        }

       // private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
       // {
            
            
           // VerfiyFinger aa = new VerfiyFinger();
           // aa.Show();
       // }


    }
}
